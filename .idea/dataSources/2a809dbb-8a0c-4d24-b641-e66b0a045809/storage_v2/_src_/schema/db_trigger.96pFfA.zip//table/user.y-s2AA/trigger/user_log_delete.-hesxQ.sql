create definer = root@localhost trigger user_log_delete
    after delete
    on user
    for each row
BEGIN
  DECLARE s1 VARCHAR(64) character set utf8; # 语句①：定义变量 s1，后面发现中文字符编码出现乱码时设置字符集
  SET s1 = "删除";  # 语句②：为 s1 赋值
  INSERT INTO user_log(`current_user`, `operation`, `name`) VALUES(USER(), s1, OLD.name); # 语句③：OLD 关键字，代表未删除之前 user 表的数据
END;

