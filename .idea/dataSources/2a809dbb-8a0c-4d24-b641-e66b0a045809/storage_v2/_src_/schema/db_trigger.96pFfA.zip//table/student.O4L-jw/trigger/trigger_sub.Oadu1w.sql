create definer = root@localhost trigger trigger_sub
    after delete
    on student
    for each row
BEGIN
  UPDATE class SET num = num - 1 WHERE cid = old.cno;
END;

