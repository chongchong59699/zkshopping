create definer = root@localhost trigger user_log_update
    after update
    on user
    for each row
BEGIN
  DECLARE s1 VARCHAR(64) CHARACTER SET utf8;
  SET s1 = "更新";
  INSERT INTO user_log(`current_user`, `operation`, `name`) VALUES(USER(), s1, CONCAT(OLD.name, ' -> ', NEW.name));
END;

