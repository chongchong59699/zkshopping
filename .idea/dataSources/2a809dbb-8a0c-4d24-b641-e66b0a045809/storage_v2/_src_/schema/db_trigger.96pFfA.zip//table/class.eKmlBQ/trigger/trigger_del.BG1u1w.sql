create definer = root@localhost trigger trigger_del
    before delete
    on class
    for each row
BEGIN
  DELETE FROM student WHERE cno = OLD.cid;
END;

