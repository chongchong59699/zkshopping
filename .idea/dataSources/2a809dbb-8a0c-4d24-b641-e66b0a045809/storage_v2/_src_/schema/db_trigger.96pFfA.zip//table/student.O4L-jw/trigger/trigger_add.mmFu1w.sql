create definer = root@localhost trigger trigger_add
    after insert
    on student
    for each row
BEGIN
  UPDATE class SET num = num + 1 WHERE cid = new.cno;
END;

